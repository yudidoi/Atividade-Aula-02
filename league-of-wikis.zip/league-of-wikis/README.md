# League of Wikis — Protótipo

Protótipo funcional de página única inspirado visualmente em League of
Legends, com foco em campeões, skins, runas e habilidades.

**Este é um projeto fictício e não oficial.** Não possui vínculo com a
Riot Games. League of Legends e seus elementos são propriedades de seus
respectivos detentores. Veja o disclaimer completo no rodapé do site.

---

## Objetivo

Demonstrar, num protótipo front-end sem backend, uma experiência de
navegação premium no estilo "hub de jogo" — header fixo, carrossel de
destaques, vitrines de campeões e skins, parallax lateral e footer
institucional — usando a identidade visual Hextech (paleta, tipografia
e linguagem visual de League of Legends) como referência.

## Tecnologias utilizadas

| Tecnologia | Uso |
|---|---|
| [React 19](https://react.dev) | Biblioteca de UI |
| [Vite](https://vite.dev) | Build tool e dev server |
| JavaScript (ES2022+) | Sem TypeScript, por decisão de escopo do protótipo |
| CSS moderno (custom properties, `clamp()`, `aspect-ratio`) | Estilização, sem framework de CSS |
| [Rellax](https://dixonandmoe.com/rellax/) | Efeito parallax das faixas laterais |
| [react-icons](https://react-icons.github.io/react-icons/) | Ícones (Feather + Font Awesome) |
| [oxlint](https://oxc.rs) | Linter |

Sem backend, autenticação real ou banco de dados — todo o conteúdo vem
de arquivos estáticos em `src/data/`.

## Como instalar e executar

Pré-requisito: Node.js 18 ou superior.

```bash
# 1. Instalar dependências
npm install

# 2. Rodar em modo desenvolvimento (http://localhost:5173)
npm run dev

# 3. (opcional) Gerar build de produção em /dist
npm run build

# 4. (opcional) Servir a build de produção localmente
npm run preview

# 5. (opcional) Rodar o linter
npm run lint
```

## Estrutura do projeto

```
src/
  components/     # Peças reutilizáveis (Header, cards, carrossel genérico...)
  sections/       # Seções de página, compostas a partir dos components
  data/           # Conteúdo estático (campeões, skins, destaques)
  styles/         # Variáveis globais (paleta, tipografia) e reset
  utils/          # Funções auxiliares (scroll suave, hook de entrada)
public/
  favicon.svg     # Ícone do site
```

### Componentes principais

- **`Header`** — navegação fixa (Início, Campeões, Skins, Runas,
  Habilidades, Perfil), busca, engrenagem e avatar. Menu colapsa em
  hambúrguer abaixo de 900px.
- **`ParallaxStripe`** — faixas decorativas nas bordas laterais com o
  texto "LEAGUE OF WIKIS" em movimento contínuo via Rellax. Somem
  abaixo de 1100px e quando o sistema tem `prefers-reduced-motion`
  ativado.
- **`CardCarousel`** — carrossel horizontal genérico (scroll nativo
  com snap + setas), reaproveitado pelas seções de Campeões e Skins.
- **`ChampionCard`** / **`SkinCard`** — cards de campeão (imagem +
  nome) e de skin (imagem, campeão, nome, raridade, valor em RP), com
  fallback visual caso a imagem falhe ao carregar.
- **`HighlightsCarousel`** (seção) — carrossel circular de destaque
  com autoplay, pausa ao passar o mouse/focar, navegação manual e
  slide central ampliado.
- **`Footer`** (seção) — links institucionais, redes sociais, seletor
  de idioma (protótipo) e disclaimer de copyright.

### Funcionamento dos carrosséis

- **Destaques**: `highlights.js` define os 10 campeões fixos. O
  componente calcula a posição relativa de cada slide ao ativo
  (`-2..2`) para desenhar a profundidade e avança sozinho a cada
  5,5s, pausando ao passar o mouse ou focar via teclado (setas
  ←/→ também funcionam).
- **Campeões / Skins**: usam o mesmo `CardCarousel`, que rola
  horizontalmente com `scroll-snap`. As setas ficam ocultas em telas
  pequenas (≤640px), priorizando o gesto de arrastar/deslizar.

### Parallax (Rellax)

Cada `ParallaxStripe` instancia `new Rellax(elemento, { speed })` num
`useEffect`, com `speed` diferente entre a faixa esquerda (-2) e a
direita (-3) para reforçar a sensação de profundidade. O texto usa
`writing-mode: vertical-rl`. É puramente decorativo:
`aria-hidden="true"` e `pointer-events: none`.

## Identidade visual

Paleta Hextech definida em `src/styles/variables.css`:

| Cor | Hex | Uso |
|---|---|---|
| Azul profundo | `#091428` | Fundo base |
| Azul-esverdeado escuro | `#0A323C` | Painéis, cards |
| Ciano Hextech | `#0AC8B9` | Interação, hover, foco |
| Ouro Hextech | `#C8AA6E` | Bordas, texto de destaque |
| Ouro pálido / pergaminho | `#F0E6D2` | Texto principal |
| Azul mágico | `#005A82` | Sombras, gradiente do footer |

**Tipografia**: as fontes oficiais da Riot (*Beaufort for LOL* e
*Spiegel*) não são de uso livre, então o protótipo usa fontes do
Google Fonts com o mesmo caráter visual — **Cinzel/Marcellus** para
títulos (display, monumental) e **Spectral** para corpo de texto
(serif de leitura), carregadas em `src/styles/global.css`.

## Decisões de arquitetura

- **Dados separados dos componentes** (`src/data/*.js`): trocar um
  campeão, skin ou destaque não exige tocar em nenhum componente.
- **`CardCarousel` genérico**: em vez de duplicar a lógica de scroll
  entre Campeões e Skins, um único componente recebe os cards como
  `children`.
- **Sem TypeScript**: decisão tomada na Etapa 0 para manter o
  protótipo simples, dado o escopo definido.
- **Header + offset centralizados**: a compensação da altura do
  header fixo é feita uma única vez no `<main>` (`App.css`), não em
  cada seção individualmente.

## Fontes de dados (evitando informação inventada)

- **Campeões e destaques**: nomes, títulos e splash arts vêm da CDN
  pública oficial da Riot ([Data Dragon](https://developer.riotgames.com/docs/lol),
  patch 16.17.1). As descrições curtas dos destaques são uma paráfrase
  escrita para o protótipo, não uma cópia do texto oficial.
- **Skins**: nome, campeão, raridade e preço em RP foram pesquisados
  individualmente (Data Dragon, League of Legends Wiki e fontes
  especializadas) — ver comentário no topo de `src/data/skins.js`
  para o detalhamento de quais imagens têm URL exatamente confirmada
  e quais seguem o padrão de nomenclatura verificado do wiki oficial.
  Nomes em português seguem a localização oficial do cliente
  brasileiro **apenas onde a Riot realmente traduz** (ex.: "Lux
  Elementalista", "PROJETO: Yasuo") — as demais linhas de skin
  (High Noon, K/DA, Firecracker...) permanecem em inglês porque é
  assim que aparecem no cliente BR.

## Limitações do protótipo

- Sem backend: busca, "Runas", "Habilidades" e "Perfil" têm apenas
  comportamento visual (mensagem "Em breve no protótipo").
- Links do footer não navegam (`preventDefault`), como definido no
  briefing.
- 13 das 20 imagens de skin usam uma URL construída a partir de um
  padrão de nomenclatura verificado em mais de 10 exemplos reais,
  não uma URL individualmente conferida uma a uma — cada `<img>` tem
  fallback automático caso o nome fuja do padrão.
- Sem testes automatizados (fora do escopo do briefing).

## Como expandir

- **Trocar campeões/destaques**: edite `src/data/champions.js` ou
  `src/data/highlights.js`. Cada entrada precisa de um `id` que
  corresponda ao nome do campeão no Data Dragon (para a imagem
  funcionar).
- **Trocar skins**: edite `src/data/skins.js`. Preencha `image` com
  uma URL de splash art real quando tiver uma; deixe `null` para usar
  o fallback estilizado.
- **Trocar preços/raridades**: são só campos de dado
  (`price`, `rarity`) em `skins.js` — a raridade deve ser um dos
  valores exportados em `RARITY`.
- **Textos e paleta**: cores e fontes ficam centralizadas em
  `src/styles/variables.css`; basta trocar os valores das variáveis
  CSS para re-temar o site inteiro.
