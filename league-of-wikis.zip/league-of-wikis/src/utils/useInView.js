import { useEffect, useRef, useState } from 'react';

/**
 * Retorna [ref, isInView]. Quando o elemento referenciado entra na
 * viewport, isInView vira true (uma única vez) — usado para disparar
 * uma animação de entrada sutil (fade + deslocamento) nos títulos
 * de seção, sem depender de bibliotecas extras.
 */
export function useInView(options) {
  const ref = useRef(null);
  const [isInView, setIsInView] = useState(
    () => typeof IntersectionObserver === 'undefined'
  );

  useEffect(() => {
    const el = ref.current;
    if (!el || typeof IntersectionObserver === 'undefined') return undefined;

    const observer = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setIsInView(true);
          observer.disconnect();
        }
      },
      { threshold: 0.15, ...options }
    );

    observer.observe(el);
    return () => observer.disconnect();
  }, [options]);

  return [ref, isInView];
}
