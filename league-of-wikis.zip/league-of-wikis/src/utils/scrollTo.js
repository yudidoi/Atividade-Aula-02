/**
 * Rola suavemente até uma seção pelo id, compensando a altura do header fixo.
 */
export function scrollToSection(id) {
  const el = document.getElementById(id);
  if (!el) return;

  const headerHeight = getComputedStyle(document.documentElement)
    .getPropertyValue('--header-height');
  const offset = parseInt(headerHeight, 10) || 0;

  const top = el.getBoundingClientRect().top + window.pageYOffset - offset;
  window.scrollTo({ top, behavior: 'smooth' });
}

export function scrollToTop() {
  window.scrollTo({ top: 0, behavior: 'smooth' });
}
