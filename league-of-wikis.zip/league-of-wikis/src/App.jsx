import Header from './components/Header';
import ParallaxStripe from './components/ParallaxStripe';
import HighlightsCarousel from './sections/HighlightsCarousel';
import ChampionsCarousel from './sections/ChampionsCarousel';
import SkinsCarousel from './sections/SkinsCarousel';
import Footer from './sections/Footer';
import './App.css';

export default function App() {
  return (
    <>
      <a href="#topo" className="skip-link">
        Pular para o conteúdo
      </a>
      <Header />
      <ParallaxStripe side="left" speed={-2} />
      <ParallaxStripe side="right" speed={-3} />
      <main id="topo">
        <HighlightsCarousel />
        <ChampionsCarousel />
        <SkinsCarousel />
      </main>
      <Footer />
    </>
  );
}
