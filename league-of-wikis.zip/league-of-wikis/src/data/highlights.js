/**
 * Destaques da seção "Destaques" — 10 campeões fixos definidos no briefing.
 * Fonte: Riot Games Data Dragon (patch 16.17.1) — títulos oficiais dos
 * campeões; a descrição é uma paráfrase curta escrita para o protótipo,
 * não uma cópia do texto oficial. Splash arts servidas via CDN pública
 * da Riot (ddragon.leagueoflegends.com), sem necessidade de versão na URL.
 */

const splash = (id) =>
  `https://ddragon.leagueoflegends.com/cdn/img/champion/splash/${id}_0.jpg`;

export const highlights = [
  {
    id: 'Lux',
    name: 'Lux',
    title: 'a Dama da Luminosidade',
    description:
      'Demaciana capaz de moldar a luz ao seu comando, cresceu escondendo seus poderes num reino que teme a magia.',
    image: splash('Lux'),
  },
  {
    id: 'Xayah',
    name: 'Xayah',
    title: 'a Rebelde',
    description:
      'Revolucionária vastaya que luta para salvar seu povo, combatendo com velocidade e lâminas de pena afiadas.',
    image: splash('Xayah'),
  },
  {
    id: 'Katarina',
    name: 'Katarina',
    title: 'a Lâmina Sinistra',
    description:
      'Assassina noxiana de elite, filha mais velha do General Du Couteau, letal com suas adagas girando pelo campo de batalha.',
    image: splash('Katarina'),
  },
  {
    id: 'Akali',
    name: 'Akali',
    title: 'a Assassina Rebelde',
    description:
      'Abandonou a Ordem Kinkou para lutar sozinha, defendendo Ionia com tudo o que aprendeu como Punho da Sombra.',
    image: splash('Akali'),
  },
  {
    id: 'Soraka',
    name: 'Soraka',
    title: 'a Filha das Estrelas',
    description:
      'Viajante celestial que abriu mão da imortalidade para proteger os mortais dos seus próprios instintos violentos.',
    image: splash('Soraka'),
  },
  {
    id: 'Lulu',
    name: 'Lulu',
    title: 'a Feiticeira Feérica',
    description:
      'Maga yordle que cria ilusões e criaturas fantásticas ao lado de sua fada companheira, Pix, moldando a realidade ao seu redor.',
    image: splash('Lulu'),
  },
  {
    id: 'Hwei',
    name: 'Hwei',
    title: 'o Visionário',
    description:
      'Pintor melancólico de Ionia que transforma visões e memórias em arte para confrontar criminosos e consolar vítimas.',
    image: splash('Hwei'),
  },
  {
    id: 'Mel',
    name: 'Mel',
    title: 'o Reflexo da Alma',
    description:
      'Herdeira presumida da Casa Medarda, uma aristocrata refinada e política habilidosa que sabe tudo sobre todos ao seu redor.',
    image: splash('Mel'),
  },
  {
    id: 'Kayle',
    name: 'Kayle',
    title: 'a Justiceira',
    description:
      'Nascida de um Aspecto de Targon, lutou ao lado da irmã gêmea Morgana como protetora de Demacia com asas de chama divina.',
    image: splash('Kayle'),
  },
  {
    id: 'Jhin',
    name: 'Jhin',
    title: 'o Virtuose',
    description:
      'Criminoso meticuloso que trata o assassinato como arte, usando sua arma como pincel em performances mortais e teatrais.',
    image: splash('Jhin'),
  },
];
