/**
 * 20 campeões para a seção "Campeões" (imagem + nome apenas).
 * IDs conferem com o Data Dragon (Riot) — usados para montar a URL
 * da splash art. Escolhidos pelo desenvolvedor entre personagens reais
 * de League of Legends, conforme permitido no briefing.
 */

const splash = (id) =>
  `https://ddragon.leagueoflegends.com/cdn/img/champion/loading/${id}_0.jpg`;

export const champions = [
  { id: 'Ahri', name: 'Ahri', image: splash('Ahri') },
  { id: 'Yasuo', name: 'Yasuo', image: splash('Yasuo') },
  { id: 'Zed', name: 'Zed', image: splash('Zed') },
  { id: 'Vi', name: 'Vi', image: splash('Vi') },
  { id: 'Jinx', name: 'Jinx', image: splash('Jinx') },
  { id: 'Ezreal', name: 'Ezreal', image: splash('Ezreal') },
  { id: 'Thresh', name: 'Thresh', image: splash('Thresh') },
  { id: 'Leona', name: 'Leona', image: splash('Leona') },
  { id: 'Darius', name: 'Darius', image: splash('Darius') },
  { id: 'Garen', name: 'Garen', image: splash('Garen') },
  { id: 'Ashe', name: 'Ashe', image: splash('Ashe') },
  { id: 'Braum', name: 'Braum', image: splash('Braum') },
  { id: 'Riven', name: 'Riven', image: splash('Riven') },
  { id: 'Vayne', name: 'Vayne', image: splash('Vayne') },
  { id: 'Malphite', name: 'Malphite', image: splash('Malphite') },
  { id: 'Nami', name: 'Nami', image: splash('Nami') },
  { id: 'Sejuani', name: 'Sejuani', image: splash('Sejuani') },
  { id: 'Camille', name: 'Camille', image: splash('Camille') },
  { id: 'Aphelios', name: 'Aphelios', image: splash('Aphelios') },
  { id: 'XinZhao', name: 'Xin Zhao', image: splash('XinZhao') },
];
