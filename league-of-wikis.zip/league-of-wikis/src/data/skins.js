/**
 * ~20 skins para a seção "Skins". Nomes, campeões, raridade e preço (RP)
 * foram verificados via pesquisa (Data Dragon / League of Legends Wiki /
 * fontes especializadas), não inventados — conforme exigido no briefing.
 *
 * NOMES EM PT-BR: a Riot só traduz oficialmente o nome de algumas linhas
 * de skin no cliente brasileiro (ex.: "Elementalist" -> "Elementalista",
 * "PROJECT" -> "PROJETO", "Star Guardian" -> "Guardiã Estelar",
 * "Spirit Blossom" -> "Florescer Espiritual" — confirmado via wiki de
 * dublagem PT-BR). As demais linhas (High Noon, K/DA, Firecracker, Coven,
 * Nightbringer, Blood Moon, Dragonslayer, Woad King, Beast Hunter) são
 * mantidas em inglês mesmo no cliente brasileiro — não é tradução
 * ausente, é assim que o jogo realmente exibe esses nomes no Brasil.
 *
 * Mapeamento de raridade (nomenclatura do briefing -> tier oficial da Riot):
 *   Comum   -> tiers básicos (520–750 RP)
 *   Raro    -> tiers intermediários (975 RP)
 *   Épico   -> Epic (1350 RP)
 *   Lendário -> Legendary (1820 RP)
 *   Mítico  -> Ultimate (3250 RP) — usado aqui para representar o tier
 *              máximo de forma compatível com os termos pedidos no briefing.
 *
 * "image": 7 URLs vêm de códigos numéricos de skin confirmados via busca
 * (Lux, Ezreal, Braum, Camille, Darius, Katarina, e Aphelios via fetch
 * direto). As demais 13 usam o padrão de nomenclatura de arquivo do wiki
 * oficial (`Campeao_LinhaDeSkinSemEspacoSkin.jpg`), confirmado em mais de
 * 10 exemplos reais (Vayne, Aphelios) durante a pesquisa — mesmo padrão,
 * alta confiança, mas não uma URL individualmente conferida uma a uma.
 * Todo <img> tem fallback automático (RarityBadge + card estilizado) caso
 * algum nome fuja do padrão.
 */

export const RARITY = {
  COMUM: 'Comum',
  RARO: 'Raro',
  EPICO: 'Épico',
  LENDARIO: 'Lendário',
  MITICO: 'Mítico',
};

const wikiImg = (file) =>
  `https://wiki.leagueoflegends.com/en-us/images/${file}`;
const ddragonSplash = (champion, num) =>
  `https://ddragon.leagueoflegends.com/cdn/img/champion/splash/${champion}_${num}.jpg`;

export const skins = [
  {
    id: 'lux-elementalist',
    champion: 'Lux',
    name: 'Lux Elementalista',
    rarity: RARITY.MITICO,
    price: 3250,
    image: ddragonSplash('Lux', 7),
  },
  {
    id: 'ezreal-pulsefire',
    champion: 'Ezreal',
    name: 'Pulsefire Ezreal',
    rarity: RARITY.MITICO,
    price: 3250,
    image: ddragonSplash('Ezreal', 5),
  },
  {
    id: 'akali-starguardian',
    champion: 'Akali',
    name: 'Guardiã Estelar Akali',
    rarity: RARITY.LENDARIO,
    price: 1820,
    image: wikiImg('Akali_StarGuardianSkin.jpg'),
  },
  {
    id: 'ashe-highnoon',
    champion: 'Ashe',
    name: 'High Noon Ashe',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Ashe_HighNoonSkin.jpg'),
  },
  {
    id: 'thresh-spiritblossom',
    champion: 'Thresh',
    name: 'Florescer Espiritual Thresh',
    rarity: RARITY.LENDARIO,
    price: 1820,
    image: wikiImg('Thresh_SpiritBlossomSkin.jpg'),
  },
  {
    id: 'leona-highnoon',
    champion: 'Leona',
    name: 'High Noon Leona',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Leona_HighNoonSkin.jpg'),
  },
  {
    id: 'yasuo-project',
    champion: 'Yasuo',
    name: 'PROJETO: Yasuo',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Yasuo_PROJECTSkin.jpg'),
  },
  {
    id: 'zed-project',
    champion: 'Zed',
    name: 'PROJETO: Zed',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Zed_PROJECTSkin.jpg'),
  },
  {
    id: 'vi-project',
    champion: 'Vi',
    name: 'PROJETO: Vi',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Vi_PROJECTSkin.jpg'),
  },
  {
    id: 'katarina-highnoon',
    champion: 'Katarina',
    name: 'High Noon Katarina',
    rarity: RARITY.EPICO,
    price: 1350,
    image: ddragonSplash('Katarina', 37),
  },
  {
    id: 'jinx-firecracker',
    champion: 'Jinx',
    name: 'Firecracker Jinx',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Jinx_FirecrackerSkin.jpg'),
  },
  {
    id: 'ahri-kda',
    champion: 'Ahri',
    name: 'K/DA Ahri',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Ahri_KDASkin.jpg'),
  },
  {
    id: 'braum-eltigre',
    champion: 'Braum',
    name: 'El Tigre Braum',
    rarity: RARITY.EPICO,
    price: 1350,
    image: ddragonSplash('Braum', 2),
  },
  {
    id: 'camille-coven',
    champion: 'Camille',
    name: 'Coven Camille',
    rarity: RARITY.EPICO,
    price: 1350,
    image: ddragonSplash('Camille', 2),
  },
  {
    id: 'aphelios-nightbringer',
    champion: 'Aphelios',
    name: 'Nightbringer Aphelios',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Aphelios_NightbringerSkin.jpg'),
  },
  {
    id: 'jhin-bloodmoon',
    champion: 'Jhin',
    name: 'Blood Moon Jhin',
    rarity: RARITY.EPICO,
    price: 1350,
    image: wikiImg('Jhin_BloodMoonSkin.jpg'),
  },
  {
    id: 'vayne-dragonslayer',
    champion: 'Vayne',
    name: 'Dragonslayer Vayne',
    rarity: RARITY.RARO,
    price: 975,
    image: wikiImg('Vayne_DragonslayerSkin.jpg'),
  },
  {
    id: 'darius-woadking',
    champion: 'Darius',
    name: 'Woad King Darius',
    rarity: RARITY.RARO,
    price: 975,
    image: ddragonSplash('Darius', 3),
  },
  {
    id: 'sejuani-beasthunter',
    champion: 'Sejuani',
    name: 'Beast Hunter Sejuani',
    rarity: RARITY.COMUM,
    price: 750,
    image: wikiImg('Sejuani_BeastHunterSkin.jpg'),
  },
  {
    id: 'garen-rugged',
    champion: 'Garen',
    name: 'Rugged Garen',
    rarity: RARITY.COMUM,
    price: 520,
    image: wikiImg('Garen_RuggedSkin.jpg'),
  },
];
