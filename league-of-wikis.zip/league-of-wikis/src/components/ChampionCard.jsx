import { useState } from 'react';
import './ChampionCard.css';

export default function ChampionCard({ name, image }) {
  const [failed, setFailed] = useState(false);

  return (
    <li className="champion-card">
      <div className="champion-card__frame">
        {!failed ? (
          <img
            src={image}
            alt={name}
            loading="lazy"
            onError={() => setFailed(true)}
          />
        ) : (
          <div className="champion-card__fallback" aria-hidden="true">
            {name.slice(0, 2).toUpperCase()}
          </div>
        )}
      </div>
      <span className="champion-card__name">{name}</span>
    </li>
  );
}
