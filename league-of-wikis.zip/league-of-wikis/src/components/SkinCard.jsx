import { useState } from 'react';
import RarityBadge from './RarityBadge';
import './SkinCard.css';

export default function SkinCard({ champion, name, rarity, price, image }) {
  const [failed, setFailed] = useState(!image);

  return (
    <li className="skin-card">
      <div className="skin-card__frame">
        {!failed ? (
          <img
            src={image}
            alt={`${name} (${champion})`}
            loading="lazy"
            onError={() => setFailed(true)}
          />
        ) : (
          <div className="skin-card__fallback" aria-hidden="true">
            <span>{champion}</span>
          </div>
        )}
        <div className="skin-card__rarity">
          <RarityBadge rarity={rarity} />
        </div>
      </div>

      <div className="skin-card__info">
        <p className="skin-card__champion">{champion}</p>
        <h3 className="skin-card__name">{name}</h3>
        <p className="skin-card__price">
          <span aria-hidden="true">◈</span> {price.toLocaleString('pt-BR')} RP
        </p>
      </div>
    </li>
  );
}
