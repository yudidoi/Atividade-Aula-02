import { RARITY } from '../data/skins';
import './RarityBadge.css';

const RARITY_CLASS = {
  [RARITY.COMUM]: 'rarity--comum',
  [RARITY.RARO]: 'rarity--raro',
  [RARITY.EPICO]: 'rarity--epico',
  [RARITY.LENDARIO]: 'rarity--lendario',
  [RARITY.MITICO]: 'rarity--mitico',
};

export default function RarityBadge({ rarity }) {
  return (
    <span className={`rarity-badge ${RARITY_CLASS[rarity] || ''}`}>
      {rarity}
    </span>
  );
}
