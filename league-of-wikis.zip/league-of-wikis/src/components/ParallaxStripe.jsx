import { useEffect, useRef } from 'react';
import Rellax from 'rellax';
import './ParallaxStripe.css';

const REPEAT_TEXT = Array(14).fill('LEAGUE OF WIKIS').join('  •  ');

/**
 * Faixa vertical decorativa nas bordas da página, com o texto
 * "LEAGUE OF WIKIS" repetido em movimento contínuo (efeito Parallax
 * via Rellax). Puramente decorativa: aria-hidden, sem cliques,
 * escondida em telas pequenas via CSS (ver ParallaxStripe.css).
 */
export default function ParallaxStripe({ side, speed = -2 }) {
  const trackRef = useRef(null);

  useEffect(() => {
    if (!trackRef.current) return undefined;

    const instance = new Rellax(trackRef.current, {
      speed,
      center: false,
      round: true,
    });

    return () => instance.destroy();
  }, [speed]);

  return (
    <div
      className={`parallax-stripe parallax-stripe--${side}`}
      aria-hidden="true"
    >
      <div className="parallax-stripe__track" ref={trackRef}>
        <span className="parallax-stripe__text">{REPEAT_TEXT}</span>
      </div>
    </div>
  );
}
