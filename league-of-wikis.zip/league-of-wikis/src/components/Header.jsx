import { useEffect, useRef, useState } from 'react';
import { FiSearch, FiSettings, FiUser, FiMenu, FiX } from 'react-icons/fi';
import { scrollToSection, scrollToTop } from '../utils/scrollTo';
import './Header.css';

const NAV_ITEMS = [
  { id: 'inicio', label: 'Início', kind: 'top' },
  { id: 'campeoes', label: 'Campeões', kind: 'scroll' },
  { id: 'skins', label: 'Skins', kind: 'scroll' },
  { id: 'runas', label: 'Runas', kind: 'placeholder' },
  { id: 'habilidades', label: 'Habilidades', kind: 'placeholder' },
  { id: 'perfil', label: 'Perfil', kind: 'placeholder' },
];

export default function Header() {
  const [scrolled, setScrolled] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [activeNotice, setActiveNotice] = useState(null);
  const [searchValue, setSearchValue] = useState('');
  const noticeTimeout = useRef(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  const showNotice = (id) => {
    setActiveNotice(id);
    clearTimeout(noticeTimeout.current);
    noticeTimeout.current = setTimeout(() => setActiveNotice(null), 2200);
  };

  const handleNavClick = (item) => {
    setMobileOpen(false);
    if (item.kind === 'top') {
      scrollToTop();
    } else if (item.kind === 'scroll') {
      scrollToSection(item.id);
    } else {
      showNotice(item.id);
    }
  };

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    // A busca será conectada aos dados de campeões/skins nas próximas etapas.
  };

  return (
    <header className={`header ${scrolled ? 'header--scrolled' : ''}`}>
      <div className="header__inner">
        <a
          href="#topo"
          className="header__brand"
          onClick={(e) => {
            e.preventDefault();
            scrollToTop();
          }}
        >
          League of Wikis
        </a>

        <button
          className="header__mobile-toggle"
          aria-label={mobileOpen ? 'Fechar menu' : 'Abrir menu'}
          aria-expanded={mobileOpen}
          onClick={() => setMobileOpen((v) => !v)}
        >
          {mobileOpen ? <FiX size={22} /> : <FiMenu size={22} />}
        </button>

        <nav
          className={`header__nav ${mobileOpen ? 'header__nav--open' : ''}`}
          aria-label="Navegação principal"
        >
          <ul>
            {NAV_ITEMS.map((item) => (
              <li key={item.id}>
                <button
                  className="header__nav-link"
                  onClick={() => handleNavClick(item)}
                >
                  {item.label}
                  {activeNotice === item.id && (
                    <span className="header__notice" role="status">
                      Em breve no protótipo
                    </span>
                  )}
                </button>
              </li>
            ))}
          </ul>
        </nav>

        <div className="header__actions">
          <form
            className="header__search"
            role="search"
            onSubmit={handleSearchSubmit}
          >
            <FiSearch aria-hidden="true" className="header__search-icon" />
            <label htmlFor="site-search" className="visually-hidden">
              Buscar campeões ou skins
            </label>
            <input
              id="site-search"
              type="search"
              placeholder="Buscar campeões, skins..."
              value={searchValue}
              onChange={(e) => setSearchValue(e.target.value)}
            />
          </form>

          <button
            className="header__icon-btn"
            aria-label="Configurações"
            onClick={() => showNotice('config')}
          >
            <FiSettings size={19} />
            {activeNotice === 'config' && (
              <span className="header__notice header__notice--icon" role="status">
                Em breve no protótipo
              </span>
            )}
          </button>

          <button
            className="header__avatar"
            aria-label="Perfil"
            onClick={() => showNotice('perfil')}
          >
            <FiUser size={18} />
            {activeNotice === 'perfil' && (
              <span className="header__notice header__notice--icon" role="status">
                Em breve no protótipo
              </span>
            )}
          </button>
        </div>
      </div>
    </header>
  );
}
