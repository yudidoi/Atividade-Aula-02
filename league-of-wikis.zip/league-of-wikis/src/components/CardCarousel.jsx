import { useEffect, useRef, useState } from 'react';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { useInView } from '../utils/useInView';
import './CardCarousel.css';

/**
 * Carrossel horizontal com scroll nativo (+ snap) e setas de navegação.
 * Genérico: recebe os itens já renderizados como children, um por card.
 * Reutilizado pelas seções de Campeões e Skins.
 */
export default function CardCarousel({ id, title, subtitle, ariaLabel, children }) {
  const trackRef = useRef(null);
  const [canPrev, setCanPrev] = useState(false);
  const [canNext, setCanNext] = useState(true);
  const [headerRef, headerInView] = useInView();

  const updateEdges = () => {
    const el = trackRef.current;
    if (!el) return;
    setCanPrev(el.scrollLeft > 8);
    setCanNext(el.scrollLeft + el.clientWidth < el.scrollWidth - 8);
  };

  useEffect(() => {
    updateEdges();
    const el = trackRef.current;
    if (!el) return undefined;
    el.addEventListener('scroll', updateEdges, { passive: true });
    window.addEventListener('resize', updateEdges);
    return () => {
      el.removeEventListener('scroll', updateEdges);
      window.removeEventListener('resize', updateEdges);
    };
  }, []);

  const scrollByPage = (dir) => {
    const el = trackRef.current;
    if (!el) return;
    el.scrollBy({ left: dir * el.clientWidth * 0.85, behavior: 'smooth' });
  };

  const handleTrackKeyDown = (e) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      scrollByPage(1);
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      scrollByPage(-1);
    }
  };

  return (
    <section id={id} className="card-carousel" aria-label={ariaLabel}>
      <div
        className={`card-carousel__header ${headerInView ? 'is-visible' : ''}`}
        ref={headerRef}
      >
        <h2>{title}</h2>
        {subtitle && <p>{subtitle}</p>}
      </div>

      <div className="card-carousel__viewport">
        <button
          className="card-carousel__control card-carousel__control--prev"
          onClick={() => scrollByPage(-1)}
          aria-label={`${title}: rolar para trás`}
          disabled={!canPrev}
        >
          <FiChevronLeft size={22} />
        </button>

        <ul
          className="card-carousel__track"
          ref={trackRef}
          tabIndex={0}
          role="group"
          aria-label={`${title}: use as setas do teclado para navegar`}
          onKeyDown={handleTrackKeyDown}
        >
          {children}
        </ul>

        <button
          className="card-carousel__control card-carousel__control--next"
          onClick={() => scrollByPage(1)}
          aria-label={`${title}: rolar para frente`}
          disabled={!canNext}
        >
          <FiChevronRight size={22} />
        </button>
      </div>
    </section>
  );
}
