import CardCarousel from '../components/CardCarousel';
import ChampionCard from '../components/ChampionCard';
import { champions } from '../data/champions';

export default function ChampionsCarousel() {
  return (
    <CardCarousel
      id="campeoes"
      title="Campeões"
      subtitle="Explore o arsenal de Runeterra"
      ariaLabel="Carrossel de campeões"
    >
      {champions.map((champ) => (
        <ChampionCard key={champ.id} name={champ.name} image={champ.image} />
      ))}
    </CardCarousel>
  );
}
