import CardCarousel from '../components/CardCarousel';
import SkinCard from '../components/SkinCard';
import { skins } from '../data/skins';

export default function SkinsCarousel() {
  return (
    <CardCarousel
      id="skins"
      title="Skins"
      subtitle="Cosméticos em destaque na loja"
      ariaLabel="Carrossel de skins"
    >
      {skins.map((skin) => (
        <SkinCard
          key={skin.id}
          champion={skin.champion}
          name={skin.name}
          rarity={skin.rarity}
          price={skin.price}
          image={skin.image}
        />
      ))}
    </CardCarousel>
  );
}
