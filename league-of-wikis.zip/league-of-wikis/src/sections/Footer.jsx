import {
  FaDiscord,
  FaInstagram,
  FaYoutube,
  FaTiktok,
} from 'react-icons/fa';
import { FaXTwitter } from 'react-icons/fa6';
import './Footer.css';

const LINK_GROUPS = [
  {
    title: 'Produto',
    links: ['Campeões', 'Skins', 'Runas', 'Habilidades', 'Perfil'],
  },
  {
    title: 'Empresa',
    links: ['Sobre o projeto', 'Carreiras', 'Imprensa', 'Marca'],
  },
  {
    title: 'Recursos',
    links: ['Suporte', 'Comunidade', 'Desenvolvedores', 'Blog'],
  },
  {
    title: 'Política',
    links: ['Termos de uso', 'Privacidade', 'Cookies', 'Diretrizes'],
  },
];

const SOCIAL_LINKS = [
  { label: 'Discord', Icon: FaDiscord },
  { label: 'X', Icon: FaXTwitter },
  { label: 'Instagram', Icon: FaInstagram },
  { label: 'YouTube', Icon: FaYoutube },
  { label: 'TikTok', Icon: FaTiktok },
];

export default function Footer() {
  return (
    <footer className="footer">
      <div className="footer__inner">
        <div className="footer__brand-col">
          <span className="footer__brand">League of Wikis</span>

          <div className="footer__language">
            <label htmlFor="footer-lang" className="visually-hidden">
              Idioma
            </label>
            <span className="footer__language-label">Idioma</span>
            <select id="footer-lang" defaultValue="pt-br">
              <option value="pt-br">Português (Brasil)</option>
              <option value="en-us">English (US)</option>
              <option value="es-es">Español</option>
            </select>
          </div>

          <div className="footer__social">
            <span className="footer__social-label">Social</span>
            <ul>
              {SOCIAL_LINKS.map(({ label, Icon }) => (
                <li key={label}>
                  <a href="#topo" aria-label={label} onClick={(e) => e.preventDefault()}>
                    <Icon size={18} />
                  </a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        <nav className="footer__groups" aria-label="Links institucionais">
          {LINK_GROUPS.map((group) => (
            <div key={group.title} className="footer__group">
              <h3>{group.title}</h3>
              <ul>
                {group.links.map((link) => (
                  <li key={link}>
                    <a href="#topo" onClick={(e) => e.preventDefault()}>
                      {link}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </nav>
      </div>

      <div className="footer__legal">
        <p>
          League of Wikis é um projeto fictício criado para fins de
          demonstração e prototipagem. League of Legends e seus respectivos
          elementos são propriedades de seus respectivos detentores.
        </p>
        <p className="footer__copyright">
          © {new Date().getFullYear()} League of Wikis. Protótipo sem fins
          comerciais.
        </p>
      </div>
    </footer>
  );
}
