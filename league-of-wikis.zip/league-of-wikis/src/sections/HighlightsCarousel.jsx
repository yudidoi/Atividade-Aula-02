import { useCallback, useEffect, useRef, useState } from 'react';
import { FiChevronLeft, FiChevronRight } from 'react-icons/fi';
import { highlights } from '../data/highlights';
import { useInView } from '../utils/useInView';
import './HighlightsCarousel.css';

const AUTOPLAY_MS = 5500;

function HighlightSlideImage({ champ, isActive }) {
  const [failed, setFailed] = useState(false);

  if (failed) {
    return (
      <div className="highlights__fallback" aria-hidden="true">
        <span>{champ.name.slice(0, 2).toUpperCase()}</span>
      </div>
    );
  }

  return (
    <img
      src={champ.image}
      alt={isActive ? `${champ.name}, ${champ.title}` : ''}
      loading={isActive ? 'eager' : 'lazy'}
      onError={() => setFailed(true)}
    />
  );
}

export default function HighlightsCarousel() {
  const [index, setIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const timerRef = useRef(null);
  const total = highlights.length;
  const [headerRef, headerInView] = useInView();

  const goTo = useCallback(
    (i) => setIndex(((i % total) + total) % total),
    [total]
  );
  const next = useCallback(() => goTo(index + 1), [index, goTo]);
  const prev = useCallback(() => goTo(index - 1), [index, goTo]);

  useEffect(() => {
    if (paused) return undefined;
    timerRef.current = setInterval(next, AUTOPLAY_MS);
    return () => clearInterval(timerRef.current);
  }, [paused, next]);

  // Posição relativa de cada slide em relação ao ativo (-2..-1,0,1..2),
  // considerando o "wrap around" do carrossel circular.
  const relativePosition = (i) => {
    let diff = i - index;
    if (diff > total / 2) diff -= total;
    if (diff < -total / 2) diff += total;
    return diff;
  };

  const handleKeyDown = (e) => {
    if (e.key === 'ArrowRight') {
      e.preventDefault();
      next();
    } else if (e.key === 'ArrowLeft') {
      e.preventDefault();
      prev();
    }
  };

  return (
    <section
      id="destaques"
      className="highlights"
      aria-roledescription="carrossel"
      aria-label="Destaques de campeões"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocus={() => setPaused(true)}
      onBlur={() => setPaused(false)}
      onKeyDown={handleKeyDown}
    >
      <div
        className={`highlights__header ${headerInView ? 'is-visible' : ''}`}
        ref={headerRef}
      >
        <h2>Destaques</h2>
        <p>Campeões em evidência nesta temporada</p>
      </div>

      <div className="highlights__viewport">
        <button
          className="highlights__control highlights__control--prev"
          onClick={prev}
          aria-label="Destaque anterior"
        >
          <FiChevronLeft size={22} />
        </button>

        <ul className="highlights__track">
          {highlights.map((champ, i) => {
            const pos = relativePosition(i);
            const isActive = pos === 0;
            const visible = Math.abs(pos) <= 2;
            const scale = 1 - Math.min(0.28, Math.abs(pos) * 0.14);

            return (
              <li
                key={champ.id}
                className={`highlights__slide ${isActive ? 'is-active' : ''}`}
                style={{
                  '--pos': pos,
                  '--scale': scale,
                  opacity: visible ? 1 - Math.abs(pos) * 0.35 : 0,
                  pointerEvents: isActive ? 'auto' : 'none',
                  zIndex: 10 - Math.abs(pos),
                }}
                aria-hidden={!isActive}
              >
                <HighlightSlideImage champ={champ} isActive={isActive} />
                {isActive && (
                  <div className="highlights__caption">
                    <h3>
                      {champ.name} <span>{champ.title}</span>
                    </h3>
                    <p>{champ.description}</p>
                  </div>
                )}
              </li>
            );
          })}
        </ul>

        <button
          className="highlights__control highlights__control--next"
          onClick={next}
          aria-label="Próximo destaque"
        >
          <FiChevronRight size={22} />
        </button>
      </div>

      <div className="highlights__dots" role="tablist" aria-label="Selecionar destaque">
        {highlights.map((champ, i) => (
          <button
            key={champ.id}
            role="tab"
            aria-selected={i === index}
            aria-label={`Ir para ${champ.name}`}
            className={`highlights__dot ${i === index ? 'is-active' : ''}`}
            onClick={() => goTo(i)}
          />
        ))}
      </div>
    </section>
  );
}
