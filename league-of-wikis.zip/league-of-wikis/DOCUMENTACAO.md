# DOCUMENTACAO.md — League of Wikis

## 1. O que é o site

**League of Wikis** é um protótipo fictício de página única (single
scroll) inspirado visualmente no universo de League of Legends, com foco
em campeões, skins, runas e habilidades. Ele não é um produto oficial e
não possui vínculo com a Riot Games. O site simula um "hub" de jogo com
header de navegação, um carrossel de campeões em destaque, uma vitrine de
20 campeões, uma vitrine de 20 skins (com raridade e valor) e um rodapé
institucional, tudo com a identidade visual "Hextech" do jogo.

## 2. Como instalar e rodar, com as bibliotecas necessárias

```bash
# Obs: Precisa do Node Modulos instalado
npm install
npm run dev       # roda em modo desenvolvimento, http://localhost:5173

```

Requer **Node.js 18+**.

**Nota importante**: este projeto é feito em React + Vite, e por isso
**não abre com um duplo clique em `index.html`** — é necessário rodar
`npm install` e depois `npm run dev` (ou `build` + `preview`), com um
servidor local de verdade. Isso é uma divergência conhecida em relação
ao formato de entrega descrito na Aula 02 (que espera um `index.html`
estático que abra sem servidor). Essa divergência foi identificada e
explicada na Etapa 0 do processo de finalização (ver `PROMPTS.md`);
migrar para uma versão estática foi oferecido como opção e **recusado
pelo usuário**, que optou por manter a arquitetura React original.

## 3. Tecnologias, com versões e o que cada uma faz

| Tecnologia | Versão | O que faz |
|---|---|---|
| React | ^19.2.8 | Biblioteca de UI — monta a interface a partir de componentes |
| Vite | ^8.2.2 | Build tool e servidor de desenvolvimento |
| **Rellax** | **^1.12.1** | Biblioteca de efeito parallax — move as faixas laterais com o texto "LEAGUE OF WIKIS" numa velocidade diferente da rolagem da página |
| react-icons | ^5.7.0 | Ícones (Feather + Font Awesome) usados no header e footer |
| oxlint | ^1.79.0 | Linter |

Sem backend, autenticação real ou banco de dados — todo o conteúdo vem
de arquivos estáticos em `src/data/`.

## 4. Revisão dos elementos que compõem o site

- **HTML** (gerado pelo React a partir do JSX): estrutura semântica da
  página (header, main, seções, footer).
- **CSS** (arquivos `.css` por componente, em `src/components/` e
  `src/sections/`, mais `src/styles/variables.css` e `global.css`):
  aparência — paleta Hextech, tipografia, espaçamento, animações de
  hover/entrada, responsividade por media query.
- **JavaScript/JSX** (componentes React em `src/components/` e
  `src/sections/`): comportamento — abre/fecha o menu mobile, controla
  os carrosséis (autoplay, pausa, navegação manual e por teclado),
  mostra o aviso de "Em breve no protótipo" nos itens sem função real,
  instancia o Rellax nas faixas laterais.
- **Dados** (`src/data/champions.js`, `highlights.js`, `skins.js`):
  arrays separados dos componentes, para que trocar um campeão, preço
  ou raridade não exija mexer na estrutura visual.
- **Biblioteca de efeito (Rellax 1.12.1)**: instanciada via
  `new Rellax(elemento, { speed })` no componente `ParallaxStripe`.
- **Carrosséis**: o de Destaques (`HighlightsCarousel`) é circular com
  autoplay; os de Campeões e Skins reaproveitam um único componente
  genérico (`CardCarousel`) com rolagem horizontal nativa.
- **Footer**: nome do site, grupos de links institucionais, redes
  sociais, seletor de idioma (protótipo) e disclaimer de copyright.
- **Fallback de imagem**: `onError` nos componentes de card substitui a
  imagem quebrada por um card estilizado com o nome do campeão/skin.

## 5. Ambiente de desenvolvimento

- **Desenvolvimento do código**: conduzido inteiramente dentro do Claude
  (ambiente de execução de código do chat), que escreveu e testou
  (`npm run build`, `npm run lint`) o projeto a cada etapa.
- **Editor de texto usado pelo usuário**: Visual Studio Code (VS Code).
- **Sistema operacional**: Windows.
- **Navegador usado para testar**: Opera GX.

## 6. Qual IA foi usada, com a versão

- **Ferramenta**: Claude (claude.ai), interface de chat da Anthropic.
- **Modelo**: Claude Sonnet 5.
