# PROMPTS.md — League of Wikis

Registro real do processo de desenvolvimento, para cumprir a exigência de
rastreabilidade da Aula 02. Os trechos abaixo são resumos fiéis do que
realmente aconteceu na conversa, não uma reconstrução idealizada.

## 1. Pedido / requisito inicial

O projeto começou com um prompt longo e detalhado (fornecido pelo
usuário) definindo o "League of Wikis": um protótipo de página única
inspirado em League of Legends, com header, carrossel de destaques (10
campeões fixos), vitrine de 20 campeões, vitrine de ~20 skins, footer,
parallax lateral com Rellax e uma identidade visual Hextech com paleta de
cores específica. Esse prompt exigia desenvolvimento por etapas, com
aprovação explícita a cada etapa, e proibia inventar dados factuais
(nomes, preços, raridades, lore).

## 2. Pesquisa / insumos

O usuário enviou um arquivo `Referencias_site.zip` com 5 imagens de
referência (header, carrossel de destaque, carrossel de campeões/skins,
footer, guia de identidade visual e faixa de parallax). Essas imagens
foram analisadas visualmente e, mais tarde nesta etapa de finalização,
identificadas como referências reais da Netflix e do Discord (ver
`INSUMOS.md`). Durante o desenvolvimento das skins, foram feitas
pesquisas na web (Data Dragon, League of Legends Wiki) para confirmar
nomes, raridades e preços reais em vez de inventar.

## 3. Pedido de plano (sem código)

Seguindo a regra do prompt original, a primeira resposta foi só uma
proposta de arquitetura de pastas (`components`, `sections`, `data`,
`styles`, `utils`) e decisões a aprovar (JavaScript vs TypeScript, fontes
livres vs oficiais, fonte das imagens), sem escrever nenhuma linha de
código — só depois da aprovação do usuário é que o código começou.

## 4. Desenvolvimento em etapas

O projeto React/Vite foi construído em 8 etapas aprovadas uma a uma:
Etapa 1 (estrutura + Header), Etapa 2 (carrossel de Destaques), Etapa 3
(carrossel de Campeões), Etapa 4 (carrossel de Skins — com correção
posterior de dados e imagens pedida pelo usuário), Etapa 5 (Footer),
Etapa 6 (Parallax com Rellax + animações de entrada), Etapa 7
(responsividade/acessibilidade) e Etapa 8 (revisão final e empacotamento
em `LEAGUE-OF-WIKIS-PROTOTYPE.zip`).

## 5. Inclusão da biblioteca de efeito

A biblioteca **Rellax 1.12.1** foi adicionada na Etapa 6, instanciada via
`new Rellax(elemento, { speed })` em cada uma das duas faixas laterais
("`ParallaxStripe`"), com velocidades diferentes (-2 e -3) para reforçar
a sensação de profundidade. Confirmado como uso real da biblioteca, não
apenas decorativo/documentado.

## 6. Correções feitas

- **Sintoma**: "não está aparecendo nada no site" — o usuário reportou
  tela em branco ao rodar localmente. **Preservar**: nada especificado.
  **Ação**: preparei um teste com navegador headless (Playwright) para
  reproduzir o erro; o usuário corrigiu por conta própria antes que o
  teste terminasse e pediu para continuar — a causa raiz não chegou a
  ser confirmada por mim.
- **Sintoma**: "não está aparecendo todas as imagens das skins" +
  pedido para traduzir os nomes para português do Brasil. **Preservar**:
  os dados já corretos (nome do campeão, raridade). **Ação**: pesquisei
  URLs de splash art adicionais (7 confirmadas por código numérico
  exato, 13 por padrão de nomenclatura do wiki oficial validado em mais
  de 10 exemplos), corrigi um erro de dado descoberto durante a pesquisa
  (High Noon Ashe/Leona são Épico/1350 RP, não Lendário/1820 RP como
  estava antes), e apliquei nomes em PT-BR só onde a Riot realmente
  traduz oficialmente (ex.: "Lux Elementalista", "PROJETO: Yasuo").
- **Sintoma** (encontrado na auditoria da Etapa 3, não reportado pelo
  usuário): o menu esquerdo do header não tinha "Perfil" no desktop —
  só aparecia no dropdown mobile e como ícone de avatar à direita,
  divergindo do prompt original (seção 6) e do master prompt (seção 7),
  que pedem "Perfil" na lista da esquerda. **Preservar**: o ícone de
  avatar à direita, os demais itens do menu, os comportamentos de
  scroll/placeholder. **Ação**: adicionei "Perfil" como item de
  `NAV_ITEMS` (mesmo comportamento de "Em breve no protótipo" de
  Runas/Habilidades) e removi o bloco `header__mobile-actions`, que
  ficou redundante.
- **Sintoma** (idem, achado na auditoria): o footer tinha "Central de
  ajuda" em vez do termo literal "Suporte" pedido no prompt original
  (seção 13). **Preservar**: os demais links, grupos e a ordem.
  **Ação**: renomeei o link para "Suporte" — troca de uma palavra,
  decisão de baixo impacto tomada sem aprovação prévia, conforme a
  exceção da seção 2 do master prompt, e registrada aqui.
- **Sintoma** (encontrado na auditoria da Etapa 5, calculando a largura
  real do header em ~360px): a soma de marca ("League of Wikis") +
  botão de menu + engrenagem + avatar + espaçamentos dava ~370px,
  passando da viewport de 360px — o avatar seria empurrado pra fora da
  área visível, já que a marca tem `flex-shrink: 0`. **Preservar**: o
  layout em telas ≥400px, todos os ícones e textos visíveis.
  **Ação**: adicionei uma media query em 400px reduzindo gap e o
  tamanho da marca, o que recalculado (com as mesmas contas) cabe em
  ~308px — folga confortável dentro de 360px.
- **Sintoma** (achado por revisão externa real — outra conversa do
  Claude auditando o projeto, severidade BAIXA): no carrossel de
  Destaques, uma imagem quebrada só sumia (`display:none`) em vez de
  mostrar um fallback estilizado, ao contrário de Campeões/Skins.
  **Preservar**: posição, autoplay, legenda, controles do carrossel.
  **Ação**: criei `HighlightSlideImage`, com o mesmo padrão de
  fallback (gradiente + iniciais) dos outros dois carrosséis.

## 7. Revisão

**Revisão externa realizada.** Feita numa **outra conversa do Claude**
(janela/sessão separada da que desenvolveu o projeto — nível 1 dos três
possíveis, conforme a Aula 02), usando um prompt de auditoria completo
(20+ critérios, matriz requisito-por-requisito, checklist de aceitação,
classificação de severidade). O auditor testou o projeto de verdade
(`npm install`, `build`, `lint`, e um navegador real via Playwright em
3 larguras — 1440px, 768px, 360px), não só leu o código.

**Resultado**: ⚠️ APROVADO COM RESSALVAS. Confirmado por teste real:
scroll do menu, autoplay dos Destaques, navegação por teclado, Rellax
realmente movendo o `transform` ao rolar, fallback de imagem
(testado sob stress — 40 imagens indisponíveis por bloqueio de rede do
ambiente do auditor, e o fallback segurou), zero overflow em
1440/768/360px, zero erros de JavaScript.

**Dois apontamentos, ambos já decididos**:
- **[CRÍTICO]** React/Vite não abre com 2 cliques sem servidor (viola
  RNF01). Já era uma decisão consciente e documentada (ver item 9 —
  usuário recusou a migração estática na Etapa 2). Mantido como está,
  a pedido do usuário.
- **[ALTO]** Registrava que a revisão externa ainda não tinha
  acontecido — **superado por esta própria revisão**, que é
  justamente essa revisão externa.

**Um achado de baixa severidade, corrigido**: no carrossel de
Destaques, uma imagem quebrada só sumia (`display:none`) em vez de
mostrar um fallback estilizado, diferente de Campeões/Skins. Corrigido
— ver correção abaixo.

**Uma observação informativa, sem ação necessária**: o auditor só
conseguiu confirmar "zero erros de console" via simulação, porque a
rede do ambiente dele bloqueia as CDNs de imagem — o mesmo tipo de
limitação já registrada aqui no item 8. Não é um problema do projeto.


## 8. Testes

Testes automatizados de build e lint foram rodados a cada etapa
(`npm run build`, `npm run lint`), sempre com resultado limpo antes de
prosseguir. Uma instalação limpa (`npm install` do zero) também foi
testada com sucesso na Etapa 8 original.

**Etapa 6 do processo de finalização — bateria de testes real**: como o
projeto React/Vite usa `<script type="module">`, e a ferramenta de teste
automatizado disponível (jsdom) não executa módulos ES — confirmado
observando o log do servidor local, que mostrou o arquivo `.js` nunca
sendo requisitado — foi gerado um build de teste temporário (mesmo
código-fonte, config alternativa gerando bundle clássico só para viabilizar
o teste; arquivo de config apagado logo depois, nunca fez parte do
projeto entregue). Resultado, com o site servido de verdade por HTTP e
todas as interações simuladas:

- `root` da página renderizou conteúdo real (não ficou em branco);
- Header, Destaques (10 slides, 1 ativo), Campeões (20 cards), Skins (20
  cards) e Footer, todos presentes no DOM final;
- os 6 itens do menu confirmados na ordem certa, incluindo "Perfil"
  (valida a correção da Etapa 3);
- o grupo "Recursos" do footer confirmado com "Suporte" (valida a
  correção da Etapa 3/4);
- **zero `window.onerror` e zero `console.error`**;
- cliques simulados em item de menu, carrossel de Destaques e de
  Campeões executaram sem lançar exceção.

**O que ainda não foi feito**: teste manual num navegador real (Opera
GX, Windows) — abrir, checar console de verdade, testar em tela
estreita de ~360px. Isso é responsabilidade do usuário e está registrado
como pendente, conforme a regra de não inventar resultado de teste — a
simulação acima aumenta a confiança, mas não substitui abrir o site de
verdade.

## 9. Finalização para a Aula 02 (este processo)

Nesta conversa, o usuário forneceu o material da Aula 02 (PDF) e um
prompt-mestre de finalização, pedindo auditoria e adequação do projeto
já existente aos requisitos acadêmicos. Uma Etapa 0 de auditoria foi
feita (matriz de conformidade, identificação do problema de arquitetura
React/Vite vs. exigência de abrir com dois cliques) e aprovada pelo
usuário. Os documentos obrigatórios (`REQUISITOS.md`, `INSUMOS.md`,
`DOCUMENTACAO.md`, `PROMPTS.md`) foram criados na Etapa 1, com decisões
sobre as referências (Netflix + Discord, a terceira imagem descartada
por vir de uma pesquisa no Google Imagens sem site de origem) e sobre o
ambiente/IA usados (Windows, Opera GX, VS Code, Claude Sonnet 5)
confirmadas diretamente pelo usuário.

**Etapa 2 — migração de arquitetura (feita e depois revertida)**: a
Opção A (reescrita estática em `index.html`/`estilo.css`/`script.js`
puros) chegou a ser implementada por completo — dados, CSS e
comportamento inteiros convertidos para JavaScript vanilla, com Rellax
via CDN — e testada com uma simulação automatizada de carregamento de
página (servidor local + jsdom), que confirmou renderização correta e
zero erros de JavaScript. **O usuário não gostou do resultado e pediu
para manter a versão React/Vite original**, acrescentando só os arquivos
que faltavam. A migração estática foi descartada a pedido do usuário.

**Decisão final**: o projeto permanece em React + Vite. Isso significa
que ele **não atende literalmente** ao critério da Aula 02 de abrir com
dois cliques sem servidor (é necessário `npm install` + `npm run dev`/
`build`) — essa divergência está registrada explicitamente no
`DOCUMENTACAO.md` (item 2) em vez de omitida, já que foi uma escolha
consciente do usuário depois de conhecer o trade-off.

---

**Revisão:** pendente de revisão externa em outra conversa/ferramenta +
validação manual do usuário (abrir o site, checar o console, testar em
tela estreita). Nenhuma revisão externa foi realizada até o momento deste
registro.

#Links dos chats: https://claude.ai/share/50ec9ff9-0000-4c89-84d4-73da0d7793fe e https://claude.ai/share/31edcfb2-fdbf-4937-b62c-0570fbefe92a